import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// Constants
const double kDefaultPadding = 16.0;
const double kCardBorderRadius = 8.0;
const double kActivityItemSize = 60.0;
const double kDetailItemIconSize = 20.0;

void main() async {
  await dotenv.load(fileName: ".env");
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dashboard App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        cardTheme: CardTheme(
          elevation: 1,
          margin: const EdgeInsets.only(bottom: kDefaultPadding / 2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(kCardBorderRadius),
          ),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _storage = const FlutterSecureStorage();
  final _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();
  
  List<Activity> activities = [];
  bool isLoading = true;
  bool showProfileMenu = false;
  String? _authToken;

  @override
  void initState() {
    super.initState();
    _loadAuthToken().then((_) => _fetchActivities());
  }

  Future<void> _loadAuthToken() async {
    _authToken = await _storage.read(key: 'auth_token') ?? dotenv.env['AUTH_TOKEN'];
  }

  Future<void> _fetchActivities() async {
    if (_authToken == null) {
      _showErrorSnackbar('Authentication required');
      return;
    }

    try {
      setState(() => isLoading = true);
      
      final response = await http.get(
        Uri.parse('${dotenv.env['API_BASE_URL']}/user/activities'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $_authToken'
        },
      ).timeout(const Duration(seconds: 10));

      debugPrint('Response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setState(() {
          activities = data.map((item) => Activity.fromJson(item)).toList();
          isLoading = false;
        });
      } else if (response.statusCode == 401) {
        throw Exception('Authentication failed');
      } else {
        throw Exception('Failed to load activities with status ${response.statusCode}');
      }
    } on TimeoutException {
      setState(() => isLoading = false);
      _showErrorSnackbar('Request timeout. Please try again');
    } on http.ClientException catch (e) {
      setState(() => isLoading = false);
      _showErrorSnackbar('Network error: ${e.message}');
    } catch (e) {
      setState(() => isLoading = false);
      _showErrorSnackbar('Failed to fetch activities: ${e.toString()}');
    }
  }

  Future<void> _handleRefresh() async {
    await _fetchActivities();
  }

  void _showErrorSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available for work'),
        actions: [
          _buildProfileAvatar(),
        ],
      ),
      body: RefreshIndicator(
        key: _refreshIndicatorKey,
        onRefresh: _handleRefresh,
        color: Colors.blue,
        strokeWidth: 3.0,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(kDefaultPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionHeader('Activities'),
              _buildActivitiesList(),
              _buildSectionHeader('Contacts'),
              _buildContactCards(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {},
      ),
    );
  }

  Widget _buildProfileAvatar() {
    return GestureDetector(
      onTap: () => setState(() => showProfileMenu = !showProfileMenu),
      child: Padding(
        padding: const EdgeInsets.all(kDefaultPadding / 2),
        child: PopupMenuButton<String>(
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'profile',
              child: Text('Profile'),
            ),
            const PopupMenuItem(
              value: 'logout',
              child: Text('Logout'),
            ),
          ],
          onSelected: (value) {
            if (value == 'logout') {
              // Handle logout
            }
          },
          child: const CircleAvatar(
            backgroundColor: Colors.blue,
            child: Icon(Icons.person, color: Colors.white),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: kDefaultPadding / 2),
      ],
    );
  }

  Widget _buildActivitiesList() {
    if (isLoading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: kDefaultPadding),
          child: CircularProgressIndicator(),
        ),
      );
    }
    if (activities.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: kDefaultPadding),
        child: Text('No activities available'),
      );
    }
    
    return SizedBox(
      height: 120,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: activities.length,
        itemBuilder: (context, index) {
          return _buildCircularActivityItem(activities[index]);
        },
      ),
    );
  }

  Widget _buildCircularActivityItem(Activity activity) {
    return Container(
      width: 80,
      margin: const EdgeInsets.symmetric(horizontal: kDefaultPadding / 2),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () => _showActivityDetails(activity),
            child: Container(
              width: kActivityItemSize,
              height: kActivityItemSize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.blue, width: 2),
              ),
              child: ClipOval(
                child: CachedNetworkImage(
                  imageUrl: activity.image,
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(
                    color: Colors.grey[200],
                    child: const Center(child: CircularProgressIndicator()),
                  ),
                  errorWidget: (context, url, error) => Container(
                    color: Colors.grey[200],
                    child: const Icon(Icons.broken_image),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: kDefaultPadding / 2),
          Text(
            activity.name,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildContactCards() {
    final contacts = [
      Contact(
        name: 'Devon Lane',
        date: '8 May',
        email: 'devon.lane@gmail.com',
        phone: '(684) 123-1234',
        note: 'Client prefers email communication for...',
        status: 'New',
      ),
      Contact(
        name: 'Floyd Miles',
        date: '9 May',
        email: 'floyd.miles@gmail.com',
        phone: '(684) 432-7654',
        note: 'Client prefers email communication.',
        status: 'In Progress',
      ),
      Contact(
        name: 'Dianne Russell',
        date: '10 May',
        email: 'dianne.russell@gmail.com',
        phone: '(684) 256-9842',
        note: 'Client prefers email communication.',
        status: 'No Answer',
      ),
      Contact(
        name: 'Ronald Richards',
        date: '11 May',
        email: 'roland.richards@gmail.com',
        phone: '(684) 342-0912',
        note: 'Client prefers email communication.',
        status: 'Converted',
      ),
    ];

    return Column(
      children: contacts.map((contact) => _buildContactCard(contact)).toList(),
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: 1,
      type: BottomNavigationBarType.fixed,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.dashboard),
          label: 'Dashboard',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.leaderboard),
          label: 'Leads',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.contacts),
          label: 'Contacts',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.account_tree),
          label: 'Pipeline',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.settings),
          label: 'Settings',
        ),
      ],
      onTap: (index) {
        // Handle navigation
      },
    );
  }

  void _showActivityDetails(Activity activity) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kCardBorderRadius * 2),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildActivityImageHeader(activity),
              Padding(
                padding: const EdgeInsets.all(kDefaultPadding),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      activity.name,
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: kDefaultPadding / 2),
                    Text(
                      activity.desc,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: kDefaultPadding),
                    _buildDetailsGrid(activity),
                    const SizedBox(height: kDefaultPadding),
                    _buildActionButtons(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActivityImageHeader(Activity activity) {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.vertical(
            top: Radius.circular(kCardBorderRadius * 2)),
          child: CachedNetworkImage(
            imageUrl: activity.image,
            height: 200,
            width: double.infinity,
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(
              height: 200,
              color: Colors.grey[200],
              child: const Center(child: CircularProgressIndicator()),
            ),
            errorWidget: (context, url, error) => Container(
              height: 200,
              color: Colors.grey[200],
              child: const Icon(Icons.broken_image, size: 50),
            ),
          ),
        ),
        Positioned(
          top: kDefaultPadding,
          right: kDefaultPadding,
          child: CircleAvatar(
            backgroundColor: Colors.black54,
            child: IconButton(
              icon: const Icon(Icons.close, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDetailsGrid(Activity activity) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      childAspectRatio: 3,
      crossAxisSpacing: kDefaultPadding / 2,
      mainAxisSpacing: kDefaultPadding / 2,
      children: [
        _buildDetailItem(
          Icons.calendar_today,
          'Created',
          DateFormat('MMM dd, yyyy').format(activity.createdAt),
        ),
        _buildDetailItem(
          Icons.update,
          'Updated',
          DateFormat('MMM dd, yyyy').format(activity.updatedAt),
        ),
        _buildDetailItem(
          Icons.category,
          'Category',
          'Beach Activity',
        ),
        _buildDetailItem(
          Icons.star,
          'Rating',
          '4.8/5',
        ),
      ],
    );
  }

  Widget _buildDetailItem(IconData icon, String label, String value) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(kCardBorderRadius),
      ),
      padding: const EdgeInsets.all(kDefaultPadding / 2),
      child: Row(
        children: [
          Icon(icon, size: kDetailItemIconSize, color: Colors.blue),
          const SizedBox(width: kDefaultPadding / 2),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Colors.grey,
                ),
              ),
              Text(
                value,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () {},
            child: const Text('Save for Later'),
          ),
        ),
        const SizedBox(width: kDefaultPadding),
        Expanded(
          child: ElevatedButton(
            onPressed: () {},
            child: const Text('Book Now'),
          ),
        ),
      ],
    );
  }

  Widget _buildContactCard(Contact contact) {
    final statusColor = _getStatusColor(contact.status);
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(kDefaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  contact.name,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  contact.date,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: kDefaultPadding / 2),
            Text(contact.email),
            const SizedBox(height: kDefaultPadding / 4),
            Text(contact.phone),
            const SizedBox(height: kDefaultPadding / 2),
            Text(contact.note),
            const SizedBox(height: kDefaultPadding / 2),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: kDefaultPadding / 2,
                vertical: kDefaultPadding / 4,
              ),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(kCardBorderRadius / 2),
                border: Border.all(color: statusColor),
              ),
              child: Text(
                contact.status,
                style: TextStyle(color: statusColor),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'New':
        return Colors.blue;
      case 'In Progress':
        return Colors.orange;
      case 'Converted':
        return Colors.green;
      case 'No Answer':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}

// Models
class Activity {
  final String id;
  final String name;
  final String desc;
  final String image;
  final DateTime createdAt;
  final DateTime updatedAt;

  Activity({
    required this.id,
    required this.name,
    required this.desc,
    required this.image,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Activity.fromJson(Map<String, dynamic> json) {
    return Activity(
      id: json['_id'] ?? '',
      name: json['name'] ?? '',
      desc: json['desc'] ?? '',
      image: json['image'] ?? '',
      createdAt: json['createdAt'] != null 
          ? DateTime.parse(json['createdAt']) 
          : DateTime.now(),
      updatedAt: json['updatedAt'] != null 
          ? DateTime.parse(json['updatedAt']) 
          : DateTime.now(),
    );
  }
}

class Contact {
  final String name;
  final String date;
  final String email;
  final String phone;
  final String note;
  final String status;

  Contact({
    required this.name,
    required this.date,
    required this.email,
    required this.phone,
    required this.note,
    required this.status,
  });
}
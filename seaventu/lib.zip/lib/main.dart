import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:seaventu/services/auth_service.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'dart:convert';

class ApiService {
  static Future<http.Response> authenticatedGet(
    BuildContext context,
    String endpoint,
  ) async {
    final authService = Provider.of<AuthService>(context, listen: false);
    final tokens = await authService.getAuthTokens();
    final token = tokens['token'];

    if (token == null) {
      throw Exception('No authentication token found');
    }

    final response = await http.get(
      Uri.parse('${dotenv.env['API_BASE_URL']}$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      },
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 401) {
      await _refreshTokenAndRetry(context);
      return authenticatedGet(context, endpoint);
    }

    return response;
  }

  static Future<http.Response> authenticatedPost(
    BuildContext context,
    String endpoint,
    dynamic body,
  ) async {
    final authService = Provider.of<AuthService>(context, listen: false);
    final tokens = await authService.getAuthTokens();
    final token = tokens['token'];

    if (token == null) {
      throw Exception('No authentication token found');
    }

    final response = await http.post(
      Uri.parse('${dotenv.env['API_BASE_URL']}$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: json.encode(body),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 401) {
      await _refreshTokenAndRetry(context);
      return authenticatedPost(context, endpoint, body);
    }

    return response;
  }

  static Future<void> _refreshTokenAndRetry(BuildContext context) async {
    final authService = Provider.of<AuthService>(context, listen: false);
    final tokens = await authService.getAuthTokens();
    final refreshToken = tokens['refreshToken'];

    if (refreshToken == null) {
      throw Exception('No refresh token found');
    }

    final response = await http.post(
      Uri.parse('${dotenv.env['API_BASE_URL']}/auth/refresh'),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: json.encode({
        'refreshToken': refreshToken,
      }),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      final newToken = responseData['token'];
      final newRefreshToken = responseData['refreshToken'];

      await authService.saveAuthTokens(newToken, newRefreshToken);
    } else {
      throw Exception('Failed to refresh token');
    }
  }
}
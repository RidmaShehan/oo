import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'session_service.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  Stream<User?> get userStream => _auth.authStateChanges();

  User? getCurrentUser() => _auth.currentUser;

  Future<User?> signInWithEmail(String email, String password) async {
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } catch (e) {
      debugPrint('Email sign in error: $e');
      return null;
    }
  }

  Future<User?> signUpWithEmail(String email, String password) async {
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } catch (e) {
      debugPrint('Email sign up error: $e');
      return null;
    }
  }

  Future<User?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth = 
          await googleUser.authentication;
      
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await _auth.signInWithCredential(credential);
      return userCredential.user;
    } catch (e) {
      debugPrint('Google sign in error: $e');
      return null;
    }
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
    await SessionService.clearAll();
  }

  Future<void> sendPasswordResetEmail(String email) async {
    await _auth.sendPasswordResetEmail(email: email);
  }

  // Token management
  Future<void> saveAuthTokens(String token, String refreshToken) async {
    await SessionService.saveAuthTokens(token, refreshToken);
  }

  Future<Map<String, String?>> getAuthTokens() async {
    return await SessionService.getAuthTokens();
  }

  Future<void> clearAuthTokens() async {
    await SessionService.clearAuthTokens();
  }

  // Credential management
  Future<void> saveCredentials(String email, String password) async {
    await SessionService.saveCredentials(email, password);
  }

  Future<Map<String, String?>> getCredentials() async {
    return await SessionService.getCredentials();
  }

  Future<void> clearCredentials() async {
    await SessionService.clearCredentials();
  }

  // Biometric authentication
  Future<bool> canUseBiometrics() async {
    // Implement your biometric check logic
    return false;
  }

  Future<bool> isBiometricEnabledForUser(String userId) async {
    // Implement your biometric status check
    return false;
  }

  Future<bool> authenticateWithBiometrics() async {
    // Implement biometric authentication
    return false;
  }

  Future<User?> authenticateWithBiometricsAndLogin() async {
    // Implement biometric login
    return null;
  }

  Future<void> setBiometricEnabledForUser(String userId, bool enabled) async {
    // Implement biometric preference saving
  }
}